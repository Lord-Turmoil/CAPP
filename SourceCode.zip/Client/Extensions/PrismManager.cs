﻿// Copyright (C) 2018 - 2024 Tony's Studio. All rights reserved.

namespace Client.Extensions;

static class PrismManager
{
    public static string MainRegionName = "MainRegionName";
}