﻿// Copyright (C) 2018 - 2024 Tony's Studio. All rights reserved.

using System.Windows.Controls;

namespace Client.Views;

/// <summary>
///     Interaction logic for PartView.xaml
/// </summary>
public partial class PartsView : UserControl
{
    public PartsView()
    {
        InitializeComponent();
    }
}