﻿// Copyright (C) 2018 - 2024 Tony's Studio. All rights reserved.

using System.Windows.Controls;

namespace Client.Views;

/// <summary>
///     Interaction logic for CreateGroupView.xaml
/// </summary>
public partial class CreateGroupView : UserControl
{
    public CreateGroupView()
    {
        InitializeComponent();
    }
}