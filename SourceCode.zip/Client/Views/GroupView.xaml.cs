﻿// Copyright (C) 2018 - 2024 Tony's Studio. All rights reserved.

using System.Windows.Controls;

namespace Client.Views;

/// <summary>
///     Interaction logic for GroupView.xaml
/// </summary>
public partial class GroupView : UserControl
{
    public GroupView()
    {
        InitializeComponent();
    }
}