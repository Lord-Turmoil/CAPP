﻿// Copyright (C) 2018 - 2024 Tony's Studio. All rights reserved.

namespace Shared.Dtos;

public class TimestampDto
{
    public DateTime CreatedAt { get; set; }

    public DateTime UpdatedAt { get; set; }
}