﻿// Copyright (C) 2018 - 2024 Tony's Studio. All rights reserved.

namespace Tonisoft.AspExtensions.Module;

public interface IService
{
}